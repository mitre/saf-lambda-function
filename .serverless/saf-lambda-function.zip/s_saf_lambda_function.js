
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'yarick',
  applicationName: 'saf-stepfunction',
  appUid: 'y2rkCjdFplwLCHcrfq',
  orgUid: '9cca0a11-2937-43cf-ba31-3b12943d69cd',
  deploymentUid: 'd398b359-3f7c-4c59-b4e2-f022b56c8b42',
  serviceName: 'saf-lambda-function',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.5.4',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'saf-lambda-function-dev-saf-lambda-function', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.lambdaHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}